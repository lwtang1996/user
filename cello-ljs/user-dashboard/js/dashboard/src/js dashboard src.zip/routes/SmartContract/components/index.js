/*
 SPDX-License-Identifier: Apache-2.0
*/
import EditModal from './editModal'
import InstallModal from './installModal'
import InstantiateModal from './instantiateModal'

export {EditModal, InstallModal, InstantiateModal}
